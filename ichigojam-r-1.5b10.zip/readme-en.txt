# IchigoJam README

Software of the Kids PC “IchigoJam”
- URL: http://ichigojam.net/index-en.html
- Date: 2021.8.10
- Version: 1.5beta10

## License
  You have to agree “Terms of Use for IchigoJam Royalty-Free Program”
  ichigojam-license-en.pdf

## Software
  - ichigojam-r.bin (IchigoJam for GD32VF103)

## You can
  - upgrade your IchigoJam you bought
  - write to the GD32VF103 for own use
  - details: license agreement

## You can’t
  - upload this software another site
  - share this software for another
  - details: license agreement

## Reference
  https://github.com/ichigojam/doc/

## Support
  https://www.facebook.com/groups/ichigojamfan/
  ichigojam@jig.jp

## License of using libs
- Xorshift RNGs by George Marsaglia
  - http://www.jstatsoft.org/v08/i14/paper
- SDL2.0
  - https://www.libsdl.org/

## Credit
(c) B Inc. (jig.jp group)
https://www.b-incorp.com/
