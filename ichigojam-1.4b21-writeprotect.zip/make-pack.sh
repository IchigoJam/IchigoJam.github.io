#!/bin/bash
cp ichigojam-ntsc-uskbd.bin ichigojam-pack.bin

cat files/0.bin >> ichigojam-pack.bin
cat files/1.bin >> ichigojam-pack.bin
cat files/2.bin >> ichigojam-pack.bin
cat files/3.bin >> ichigojam-pack.bin
