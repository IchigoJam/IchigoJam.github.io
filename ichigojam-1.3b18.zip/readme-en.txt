IchigoJam readme.txt - 2018.6.13

Software of the Kids PC “IchigoJam”
	http://ichigojam.net/index-en.html

license
	You have to agree “Terms of Use for IchigoJam Royalty-Free Program”
	ichigojam-license-en.pdf

Software
	ichigojam-[ntsc/pal]-[kbd].[hex/bin] (IchigoJam for NXP/LPC1114FN28)
		options
			ntsc for NTSC TV(60fps) / pal for PAL TV(50fps)
			uskbd for US keyboard / jpkbd for Japanese keyboard
			(mn charset for Mongol / vi charset for Vietnam)

You can
	upgrade your IchigoJam you bought
	write to the LPC1114 for own use
	details: license agreement

You can’t
	upload this software another site
	share this software for another
	details: license agreement

Support
	https://www.facebook.com/groups/ichigojamfan/
	ichigojam@jig.jp

license of using libs
	FreeGLUT
		http://freeglut.sourceforge.net
	Xorshift RNGs by George Marsaglia
		http://www.jstatsoft.org/v08/i14/paper
	SDL2.0
		https://www.libsdl.org/
