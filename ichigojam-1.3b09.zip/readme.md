# IchigoJam README

「こどもパソコンIchigoJam」のソフトウェアです
- URL: https://ichigojam.net/
- Date: 2018.5.17
- Version: 1.3b9

## はじめに

同梱の[「IchigoJam ロイヤリティフリープログラム利用規約」](ichigojam-license.pdf)に同意いただきご利用ください

## ソフトウェア
- ichigojam-(ntsc|pal)-(jp|us)kbd(-(mn|vi))?.bin (IchigoJam for NXP/LPC1114FN28)
    - オプション
        - ntsc: NTSC TV(60fps) *日本はこちら / pal: PAL TV(50fps)
        - uskbd: USキーボード / jpkbd: 日本語キーボード
        - (mn: モンゴル語版キャラ&IME / vi: ベトナム語版キャラ&IME)

## できること
- 購入いただいたIchigoJamをバージョンアップする
- 別途用意したNXP LPC1114に書き込みご自身で使う（ピン配置シートを貼ると便利です）
- 詳細は利用規約をご参照ください

## できないこと
- 他のサイトへ転載はできません
- 書き込んだIchigoJamを第三者に提供する場合ライセンスが必要です
- 詳細は利用規約をご参照ください

## サポート
	詳細は、Facebookグループ IchigoJam-FAN または サポートメール までお問い合わせください
	https://www.facebook.com/groups/ichigojam/
	ichigojam@jig.jp

## ライセンス表示
- FreeGLUT
    - http://freeglut.sourceforge.net
- Xorshift RNGs by George Marsaglia
	- http://www.jstatsoft.org/v08/i14/paper
- SDL2.0
	- https://www.libsdl.org/

(c) B Inc.