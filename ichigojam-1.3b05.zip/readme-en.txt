IchigoJam readme.txt - 2019.1.14

Software of the Kids PC “IchigoJam”
	http://ichigojam.net/index-en.html

license
	You have to agree “Terms of Use for IchigoJam Loyalty-Free Program”
	ichigojam-license-en.pdf

Software
	ichigojam-[options].[hex/bin] (IchigoJam for NXP/LPC1114FN28)
		options
			ntsc for NTSC TV(60fps)
			pal for PAL TV(50fps)

			uskbd for US
			jpkbd for Japanese
			frkbd for AZERTY keyboard

			mn charset for Mongol
			vi charset for Vietnam
			bp charset as Bopomofo
			iot IoT.OUT / IoT.IN() for sakura.io (save slot: just 1 program)
	ichigojam-ap
		platform
			ichigojam-ap-mac (IchigoJam for Mac OS X)
			ichigojam-ap-win.exe (IchigoJam for Windows)
				SDL2.dll - necessary
		options
			--keymapus (for US keyboard layout)
			--monglian (charmap for Mongolian)
			--vietnamese (charmap for Vietnamese)
			--bopomofo (charmap with Bopomofo)
			--nosound (no sounds)
			-D[path] (set the path to save and load)

You can
	upgrade your IchigoJam you bought
	write to the LPC1114 for own use
	details: license agreement

You can’t
	upload this software another site
	share this software for another
	details: license agreement

Support
	https://www.facebook.com/groups/ichigojamfan/
	ichigojam@jig.jp

license of using libs
	FreeGLUT
		http://freeglut.sourceforge.net
	Xorshift RNGs by George Marsaglia
		http://www.jstatsoft.org/v08/i14/paper
	SDL2.0
		https://www.libsdl.org/
