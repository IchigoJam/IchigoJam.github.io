#!/bin/sh
USBSERIAL=/dev/cu.usbserial-1110
~/Library/Arduino15/packages/SPRESENSE/tools/spresense-tools/3.0.1/flash_writer/macosx/flash_writer -s -c ${USBSERIAL} -d -n ichigojam-spr.spk
