# IchigoJam README

「こどもパソコンIchigoJam」のソフトウェアです
- URL: https://ichigojam.net/
- Date: 2023.7.14
- Version: 1.6beta2

## はじめに

同梱の[「IchigoJam ロイヤリティフリープログラム利用規約」](ichigojam-license.pdf)に同意いただきご利用ください

## ソフトウェア
- ichigojam-spr.spk (IchigoJam for Spresense)

## できること
- 購入いただいたIchigoJamをバージョンアップする
- 別途用意したSpresenseに書き込みご自身で使う
- 詳細は利用規約をご参照ください

## できないこと
- 他のサイトへ転載はできません
- 書き込んだIchigoJamを第三者に提供する場合ライセンスが必要です
- 詳細は利用規約をご参照ください

## 書き込み方

  SDカードにmp3decoderを書き込み、Spresenseに挿し込んでおきます
    0.mp3 〜 9.mp3 が、SPR.PLAY n コマンドで再生できます
    任意のファイル名を SPR.PLAY "fn" コマンドで再生できます
  write.sh を使って ichigojam-spr.spk をSpresenseに書き込みます

## リファレンス
  https://github.com/ichigojam/doc/

## サポート
  詳細は、Facebookグループ IchigoJam-FAN または サポートメール までお問い合わせください
  https://www.facebook.com/groups/ichigojam/
  ichigojam@jig.jp

## ライセンス表示
- Xorshift RNGs by George Marsaglia
  - http://www.jstatsoft.org/v08/i14/paper
- SDL2.0
  - https://www.libsdl.org/

## 著作
(c) B Inc. (jig.jp group)
https://www.b-incorp.com/
