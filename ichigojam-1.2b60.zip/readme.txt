IchigoJam readme.txt - 2018.7.18

「こどもパソコンIchigoJam」のソフトウェアです
	http://ichigojam.net/

はじめに
	「IchigoJam ロイヤリティフリープログラム利用規約」に同意いただきご利用ください
	ichigojam-license.pdf

ソフトウェア
	ichigojam-[ntsc/pal]-[kbd].[hex/bin] (IchigoJam for NXP/LPC1114FN28)
		オプション
			ntsc: NTSC TV(60fps) *日本はこちら / pal: PAL TV(50fps)
			uskbd: USキーボード / jpkbd: 日本語キーボード / frkbd: AZERTYキーボード
			(mn: モンゴル語版キャラ&IME / vi: ベトナム語版キャラ&IME）
	ichigojam-iot-[ntsc/pal]-[kbd].[hex/bin] (IchigoJam for NXP/LPC1114FN28)
		IoT.OUT / IoT.IN() for sakura.io
		1ファイルのみ保存可能
	ichigojam-ap
		platform
			ichigojam-ap-mac (IchigoJam for Mac OS X)
			ichigojam-ap-win.exe (IchigoJam for Windows)
				SDL2.dll を同ディレクトリに置いた状態で起動
		options
			--keymapus (USキーボードレイアウト)
			--monglian (キャラクターマップをモンゴル語版へ)
			--vietnamese (キャラクターマップをベトナム語版へ)
			--nosound (サウンドなし)
			-D[path] (ファイルの保存先を[pah]へ)


できること
	購入いただいたIchigoJamをバージョンアップする
	別途用意したNXP LPC1114に書き込みご自身で使う（ピン配置シートを貼ると便利です）
	詳細は利用規約をご参照ください

できないこと
	他のサイトへ転載はできません
	書き込んだIchigoJamを第三者に提供する場合ライセンスが必要です
	詳細は利用規約をご参照ください

サポート
	詳細は、Facebookグループ IchigoJam-FAN または サポートメール までお問い合わせください
	https://www.facebook.com/groups/ichigojam/
	ichigojam@jig.jp

ライセンス表示
	FreeGLUT
		http://freeglut.sourceforge.net
	Xorshift RNGs by George Marsaglia
		http://www.jstatsoft.org/v08/i14/paper
	SDL2.0
		https://www.libsdl.org/
