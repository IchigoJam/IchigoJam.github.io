IchigoJam readme.txt - 2018.5.18

Software of the Kids PC “IchigoJam”
	http://ichigojam.net/index-en.html

license
	You have to agree “IchigoJam ロイヤリティフリープログラム利用規約”
	ichigojam-license.pdf

Software
	ichigojam-[ntsc/pal]-[kbd].[hex/bin] (IchigoJam for NXP/LPC1114FN28)
		options
			ntsc for NTSC TV(60fps) / pal for PAL TV(50fps)
			uskbd for US keyboard / jpkbd for Japanese keyboard
			(mn charset for Mongol / vi charset for Vietnam)
	ichigojam-ap
		platform
			ichigojam-ap-mac (IchigoJam for Mac OS X)
			ichigojam-ap-win.exe (IchigoJam for Windows)
				SDL2.dll - necessary
		options
			--keymapus (for US keyboard layout)
			--monglian (charmap for Mongolian)
			--vietnamese (chairman for Vietnamese)
			--nosound (no sounds)
			-D[path] (set the path to save and load)

You can
	upgrade your IchigoJam you bought
	write to the LPC1114 for own use
	details: license agreement

You can’t
	upload this software another site
	share this software for another
	details: license agreement

Support
	https://www.facebook.com/groups/ichigojamfan/
	ichigojam@jig.jp

license of using libs
	FreeGLUT
		http://freeglut.sourceforge.net
	Xorshift RNGs by George Marsaglia
		http://www.jstatsoft.org/v08/i14/paper
	SDL2.0
		https://www.libsdl.org/
